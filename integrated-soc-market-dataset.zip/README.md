# Integrated SoC Market — Dataset

This dataset contains structured metadata and summaries derived from the public landing page of the Integrated System-on-Chip Market report (SE3564) by Next Move Strategy Consulting.

Includes:
- metadata.json
- summary.txt
- segments.csv
- companies.csv
- table_of_contents.md
- license.txt

Only publicly available information is included — no paid report content.
